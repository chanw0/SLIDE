#' @import MASS
#' @export SILDE ld.em permuC
NULL
